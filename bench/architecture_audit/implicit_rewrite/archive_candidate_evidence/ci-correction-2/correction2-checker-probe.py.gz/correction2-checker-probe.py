import hashlib,json,pathlib,subprocess,sys,time,zipfile
sys.path.insert(0,'/tmp/rusty-tiles-a2-semantics-settlement/tests')
import f1d1_oracle as oracle
import f1d2_certificate as certificate
binary=pathlib.Path('/tmp/rusty-tiles-archive-read-final-evidence/rusty-tiles-portable-5c68f7b')
out=pathlib.Path('/tmp/rusty-tiles-archive-read-final-evidence/correction2-checker')
out.mkdir(exist_ok=True)
rows=[]
for variant,limit in [('grid',16),('bump',2)]:
    source=oracle.fixture(variant,4)
    input_path=out/(variant+'.glb');input_path.write_bytes(source)
    archive=out/(variant+'.3tz')
    command=[str(binary),'--json','mesh-local-to-3tz','-i',str(input_path),'-o',str(archive),'--leaf-triangles','16','--root-proxy-triangles',str(limit),'--max-proxy-error-metres','0.5']
    completed=subprocess.run(command,capture_output=True,text=True,timeout=60)
    assert completed.returncode==0,(completed.stdout,completed.stderr)
    with zipfile.ZipFile(archive) as z:members={n:z.read(n) for n in z.namelist() if n!='@3dtilesIndex1@'}
    start=time.monotonic()
    checked=oracle.inspect_members(source,members,16,limit,0.5,max_checker_seconds=60)
    elapsed=time.monotonic()-start
    controls=[]
    for name,options in [('time',{'max_checker_seconds':1e-12}),('work',{'max_checker_tests':1})]:
        try:oracle.inspect_members(source,members,16,limit,0.5,**options)
        except certificate.CertificateUnproven as e:controls.append({'ceiling':name,'failure':str(e)})
        else:raise AssertionError('exhaustion incorrectly accepted '+name)
    rows.append({'variant':variant,'command':command,'stdout':completed.stdout,'stderr':completed.stderr,'input_sha256':hashlib.sha256(source).hexdigest(),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'elapsed_seconds':elapsed,'checked':checked,'exhaustion_controls':controls})
receipt={'classification':'Actual existing producer artifact plus bounded independent checker capacity proof; not corrected archive binary acceptance','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'checker_source_sha256':{n:hashlib.sha256((pathlib.Path('/tmp/rusty-tiles-a2-semantics-settlement/tests')/n).read_bytes()).hexdigest() for n in ['f1d1_oracle.py','f1d2_certificate.py']},'max_tests':100000,'max_depth':24,'max_seconds':60,'rows':rows}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'passed':len(rows),'elapsed':[r['elapsed_seconds'] for r in rows],'exhaustion_controls':sum(len(r['exhaustion_controls']) for r in rows)}))
