import os, sys
os.setpriority(os.PRIO_PROCESS, 0, 10)
os.sched_setaffinity(0, {0, 1})
os.environ.update(CARGO_BUILD_JOBS="2", RAYON_NUM_THREADS="2", RUST_TEST_THREADS="2", CARGO_TARGET_DIR="/tmp/rusty-tiles-f1d2-final-target")
os.execvpe(sys.argv[1], sys.argv[1:], os.environ)
