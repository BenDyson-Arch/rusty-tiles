import pathlib,subprocess,sys,json,hashlib,time
root=pathlib.Path('/tmp/rusty-tiles-c1-payload-foundation');evidence=pathlib.Path('/tmp/rusty-tiles-payload-final-evidence');pin=json.loads((evidence/'final-build/source-pin.json').read_text());records=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 for group in ['production_sha256','acceptance_inputs_sha256']:
  for name,h in pin[group].items():assert sha(root/name)==h,name
verify()
for flavor in ['portable','native']:
 binary=pathlib.Path((evidence/('final-'+flavor+'-cli.path')).read_text());binary_sha=sha(binary)
 commands=[
  ('c1-corpus',[sys.executable,'-B','tests/c1_validation_oracle.py','--binary',str(binary),'--generate',str(evidence/(flavor+'-c1-fixtures'))]),
  ('archive45',[sys.executable,'-B','tests/archive_read_oracle.py','--binary',str(binary),'--work',str(evidence/(flavor+'-archive45'))]),
  ('resources20',[sys.executable,'-B','bench/architecture_audit/c1/resource_probe.py','--binary',str(binary),'--work',str(evidence/(flavor+'-resources20'))]),
  ('producer',[sys.executable,'-B',str(evidence/'c1-producer-local-two-workers.py'),'--binary',str(binary),'--work',str(evidence/(flavor+'-producer'))]),
 ]
 for name,command in commands:
  output=evidence/(flavor+'-'+name+'.json');command+=['--output',str(output)];log=evidence/(flavor+'-'+name+'.log');started=time.monotonic()
  with log.open('wb') as stream:run=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
  verify();assert sha(binary)==binary_sha
  row={'flavor':flavor,'name':name,'command':command,'binarySha256':binary_sha,'sourceCommit':pin['source_commit'],'sourcePinSha256':sha(evidence/'final-build/source-pin.json'),'exitCode':run.returncode,'elapsedSeconds':time.monotonic()-started,'logSha256':sha(log),'outputSha256':sha(output) if output.exists() else None,'inputsAndBinaryUnchanged':True}
  records.append(row);(evidence/'integration-executions.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
  assert run.returncode==0,log
