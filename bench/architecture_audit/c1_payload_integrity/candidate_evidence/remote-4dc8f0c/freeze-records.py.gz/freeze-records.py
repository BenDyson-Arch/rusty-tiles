import gzip, hashlib, json, pathlib

source = pathlib.Path(__file__).parent
destination = source / 'retained-records'
assert not destination.exists()
destination.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
records = []
for file in sorted(source.rglob('*')):
    if not file.is_file() or destination in file.parents:
        continue
    if file.suffix not in {'.json', '.md', '.py', '.log', '.stdout', '.stderr'}:
        continue
    relative = file.relative_to(source)
    raw = file.read_bytes()
    packed = gzip.compress(raw, compresslevel=6, mtime=0)
    stored = destination / (str(relative) + '.gz')
    stored.parent.mkdir(parents=True, exist_ok=True)
    stored.write_bytes(packed)
    assert gzip.decompress(stored.read_bytes()) == raw
    records.append({'path': str(relative) + '.gz', 'sourceRecord': str(relative),
                    'uncompressedBytes': len(raw), 'uncompressedSha256': sha(raw),
                    'storedBytes': len(packed), 'storedSha256': sha(packed)})
index = {'head': '4dc8f0c04dd5a98420768d05c6787f3baa49bb75',
         'tree': '57095507d251e4f2fcb826cee367fa72bd306158',
         'mainRun': 38050915453, 'wheelRun': 38050915448,
         'scope': 'Lossless text evidence frozen after accepted merge. Binary ZIP, wheel, executable and source package bytes stay external; actual downloaded byte hashes are retained in receipts.',
         'records': records}
out = destination / 'index.json'
out.write_text(json.dumps(index, indent=2) + '\n')
print('retained', len(records), 'records; index', sha(out.read_bytes()))
