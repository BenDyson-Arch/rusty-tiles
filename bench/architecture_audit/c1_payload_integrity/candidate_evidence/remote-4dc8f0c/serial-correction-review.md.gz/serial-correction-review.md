# Separate CI capture correction review, 2026-10-10

**Bounded local CI scheduling/capture correction accepted** at head
`4dc8f0c04dd5a98420768d05c6787f3baa49bb75`, tree
`57095507d251e4f2fcb826cee367fa72bd306158`. Separate reviewer
`/root/payload_final_source_review` performed only read-only Git, file, hash,
gzip and actual log/receipt inspection. No Cargo, target execution, repository
mutation or heavy workload was performed by the reviewer.

The actual15-path commit diff is precisely the precode-approved one-line native
CI change, five original failed-capture records plus index, three targeted probe
records plus index, and four byte-identical copies of the frozen independent
precode decision. The sole workflow modification adds `--test-threads=1` to the
existing `--nocapture` native Cargo/tee step. Removing that argument recovers the
prior workflow bytes exactly. All97 production and236 other selected acceptance
inputs match both5fdf and the reviewed e4ec source pin. Original context modules,
parser, assertions, fixtures, public harnesses and owned concurrency tests are
unchanged. Earlier local source/artifact reviews retain their frozen identities.

The actual targeted controlled Cargo command runs all13 context tests with
nocapture/test-threads1. The raw log reports13 passed, zero failed/ignored,
354 filtered. It includes authentic Cargo unit discovery and records actual
dependency/root compilation before yielding the same unit SHA256
`e952cb6309597e51f3797b3ccd1743dd532721cfd08828262c5ba4e189685847`.
Both the actual target and separately frozen unit copy match. This is a fresh
targeted capture probe, not a full367 rerun, not proof that owned concurrency
tests ran in this local command, and not a claim that compilation was skipped.

The probe ran while source HEAD was5fdf/tree91b929, with only the now-committed
workflow argument modified. Its recorded workflow SHA256
`c4dc1d436c4f9369c5c1c6bfaead6acc68ce983a215acab5552a61bfad326960`
matches4dc. The actual unchanged parser names that true source base and workflow
epoch through the separately bound probe verification. Its actual unit/log,
runner and all327 production/control map hashes match the reviewed inputs. The
probe's execution identity is not silently rebound to4dc.

Raw log SHA256 is
`11f040ffc9ffca605ed2939092735e0a9278bb70d02d586fc83f572209857adf`;
parser receipt SHA256 is
`e7dd7c3fa3627e3060c11de0939e1480426e41b1dca869ded65bfbb94b1589f1`.
All82 unique raw records parse intact and equal the parser's retained records.
The reviewer independently verifies every equality/one-less fact tuple against
the frozen17-case manifest, all fifteen selected fields, read-only archive hashes,
41 complete admitted report hashes and41 ResourceLimit records. Nothing is
stitched, repaired, dropped or inferred from the original corrupted capture.

All eight newly committed lossless records match both compressed/expanded
lengths and hashes and their original files. Failure index SHA256 is
`fe4705dbfa13c1475d844d82a8112aa666c9d47624e771c386427c0940085ba8`;
probe index SHA256 is
`fc9122c72c795074a13c95bde3335e9c8b9af934b0cb4de8417e14324076853d`.
The copied decision and its three bound files match the original external phase
exactly. Old main run38049923044/Rust job114206817691 remains a failed evidence
capture despite its full library367 success. Its uploaded original log retains
the independently observed77 intact/three visibly corrupted markers; it is not
an accepted82-record receipt. Its raw/API bytes remain unchanged.

The evidence supports the narrowly owned capture correction. Serial outer test
selection prevents unrelated libtest output entering context JSON, while scoped
threads/barriers and joined child processes inside their owned concurrency tests
remain unchanged. The targeted probe does not supply universal output atomicity
or general parallel-test coverage. Full new-head remote native Cargo and owned
concurrency tests still need to execute successfully and upload all82 actual
records and217 public controls.

The reviewed C1 production/control bytes carry prior bounded local source
acceptance; the original full library/public/integration/source archive executions
remain e4ec, the targeted probe remains its actual5fdf working-workflow epoch,
and this correction review names4dc. There is no fresh4dc source-package or
full367 execution claim. New exact-head remote CI, five actual wheel builds,
ten installed-wheel validations and four official Blender/platform lanes remain
pending merge gates. No merge, A2, wider semantic or issue closure, main/tag,
publication or release acceptance is granted.
