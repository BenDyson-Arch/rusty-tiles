"""Verify workflow-only schedule correction and actual finite probe; no target run."""
import copy
import gzip
import hashlib
import json
import pathlib
import re
import subprocess

REPO = pathlib.Path('/tmp/rusty-tiles-c1-payload-foundation')
EVIDENCE = pathlib.Path('/tmp/rusty-tiles-payload-final-evidence')
HEAD = '4dc8f0c04dd5a98420768d05c6787f3baa49bb75'
PARENT = '5fdf6fb0bb15ccb404217b7e18f1414efc075a39'
TREE = '57095507d251e4f2fcb826cee367fa72bd306158'
ROOT = 'bench/architecture_audit/c1_payload_integrity/'
BASE = REPO / (ROOT + 'production_controls/context_controls/2026-10-10')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def committed(path, commit=HEAD):
    return git('show', commit + ':' + path)


assert git('rev-parse', HEAD + '^').decode().strip() == PARENT
assert git('rev-parse', HEAD + '^{tree}').decode().strip() == TREE
assert git('status', '--porcelain') == b''
pin = json.loads((EVIDENCE / 'stride-final-build/source-pin.json').read_bytes())
for group in ['production_sha256', 'acceptance_inputs_sha256']:
    for path, digest in pin[group].items():
        if path != '.github/workflows/ci.yml':
            assert sha(committed(path)) == sha(committed(path, PARENT)) == digest
            assert sha((REPO / path).read_bytes()) == digest
workflow = committed('.github/workflows/ci.yml')
assert sha(workflow) == 'c4dc1d436c4f9369c5c1c6bfaead6acc68ce983a215acab5552a61bfad326960'
assert workflow.count(b'--test-threads=1') == 1
assert workflow.replace(b' --test-threads=1', b'') == committed('.github/workflows/ci.yml', PARENT)
changes = git('diff', '--name-status', PARENT, HEAD).decode().splitlines()
assert len(changes) == 15
for row in changes:
    status, path = row.split('\t')
    if path == '.github/workflows/ci.yml':
        assert status == 'M'
    else:
        assert status == 'A' and path.startswith(tuple(ROOT + suffix for suffix in [
            'candidate_evidence/2026-10-10-ci-capture-failure/',
            'candidate_evidence/2026-10-10-ci-serial-capture-probe/',
            'final_source_review/2026-10-10-ci-capture-schedule-adjudication/',
        ]))

original_decision = EVIDENCE / 'remote-5fdf6fb/2026-10-10-ci-capture-schedule-adjudication'
decision_prefix = ROOT + 'final_source_review/2026-10-10-ci-capture-schedule-adjudication/'
decision_receipt = json.loads((original_decision / 'decision-receipt.json').read_bytes())
assert sha((original_decision / 'decision-receipt.json').read_bytes()) == 'bfd0e3ccd5ef281f1f58fe5ce50d4349b52d12a112c60a3d75aaf359e79cf6d8'
for name, digest in decision_receipt['phaseFilesSha256'].items():
    assert sha(committed(decision_prefix + name)) == digest
    assert committed(decision_prefix + name) == (original_decision / name).read_bytes()
assert committed(decision_prefix + 'decision-receipt.json') == (original_decision / 'decision-receipt.json').read_bytes()

record_count = 0
indices = {}
for dirname, count in [('2026-10-10-ci-capture-failure', 5), ('2026-10-10-ci-serial-capture-probe', 3)]:
    prefix = ROOT + 'candidate_evidence/' + dirname + '/'
    index_raw = committed(prefix + 'index.json')
    indices[dirname] = sha(index_raw)
    index = json.loads(index_raw)
    assert len(index['records']) == count
    for row in index['records']:
        packed = committed(prefix + row['file'])
        raw = gzip.decompress(packed)
        assert len(packed) == row['gzipBytes'] and sha(packed) == row['gzipSha256']
        assert len(raw) == row['rawBytes'] and sha(raw) == row['rawSha256']
        assert raw == pathlib.Path(row['sourcePath']).read_bytes()
        record_count += 1

verification = json.loads((EVIDENCE / 'ci-serial-context-probe-verification.json').read_bytes())
receipt_raw = (EVIDENCE / 'ci-serial-context-probe.json').read_bytes()
receipt = json.loads(receipt_raw)
log_raw = (EVIDENCE / 'ci-serial-context-probe.log').read_bytes()
log = log_raw.decode()
assert verification['cargoExitCode'] == 0 and verification['sourceBaseCommit'] == receipt['sourceCommit'] == PARENT
assert verification['sourceBaseTree'] == receipt['sourceTree'] == '91b929045ea153d29a4a41fc905b1d06bf90e57f'
assert verification['workflowUncommittedSha256'] == sha(workflow)
assert verification['all97ProductionAnd236OtherAcceptanceInputsUnchanged'] is True
assert verification['actualCargoArgv'][-5:] == ['--lib', 'payload_context_acceptance', '--', '--nocapture', '--test-threads=1']
assert '--no-default-features' in verification['actualCargoArgv']
assert sha(log_raw) == verification['logSha256'] == receipt['logSha256'] == '11f040ffc9ffca605ed2939092735e0a9278bb70d02d586fc83f572209857adf'
assert sha(receipt_raw) == verification['parserReceiptSha256'] == 'e7dd7c3fa3627e3060c11de0939e1480426e41b1dca869ded65bfbb94b1589f1'
unit_path = pathlib.Path(re.search(r'Running unittests src/lib.rs \(([^)]+)\)', log)[1])
assert str(unit_path) == receipt['unitArtifact']
unit_hash = sha(pathlib.Path(verification['frozenUnit']).read_bytes())
assert unit_hash == sha(unit_path.read_bytes()) == verification['unitSha256'] == receipt['unitSha256'] == 'e952cb6309597e51f3797b3ccd1743dd532721cfd08828262c5ba4e189685847'
assert re.search(r'^test result: ok\. 13 passed; 0 failed; 0 ignored; 0 measured; 354 filtered out;', log, re.M)
assert not re.search(r'^test result: ok\. 367 passed', log, re.M)
assert sha((REPO / 'tests/payload_context_receipt.py').read_bytes()) == receipt['runnerSha256']
for path, digest in receipt['sourceAndInputSha256'].items():
    assert sha(committed(path)) == digest
decoder = json.JSONDecoder()
rows = [decoder.raw_decode(line[line.index('{"actualReportSha256"'):])[0] for line in log.splitlines() if '{"actualReportSha256"' in line]
assert len(rows) == receipt['passes'] == 82 and rows == receipt['executions']
manifest = json.loads((BASE / 'fixtures/manifest.json').read_bytes())
cases = {case['name']: case for case in manifest['cases']}
expected_keys = {(case['name'], fact, outcome) for case in cases.values() for fact in (['bytes', 'depth', 'nodes'] if case['target'] else ['totalPayloadElements']) for outcome in ['admitted', 'resource_limit']}
baseline = dict(jsonBytes=65536, jsonDepth=32, memberBytes=262144, archiveStoredBytes=1048576, archiveEntries=256, accessorElements=4096, documentDecodedBytes=262144, hierarchyVisits=128, hierarchyDepth=32, references=1024, totalPayloadElements=16, totalBytesRead=4194304, sourceArchiveBytes=1048576, centralDirectoryBytes=65536, documentItems=8192)
observed = set()
for row in rows:
    name, fact, outcome = row['independentContextControl'], row['fact'], row['outcome']
    key = name, fact, outcome
    assert key not in observed
    observed.add(key)
    case = cases[name]
    exact = case['metrics'][name][fact] if case['target'] else case['aggregateEquality']
    selected = baseline.copy()
    selected[dict(bytes='jsonBytes', depth='jsonDepth', nodes='documentItems').get(fact, fact)] = exact - (outcome == 'resource_limit')
    assert row['selectedLimits'] == selected and row['readOnly'] is True and row['archiveSha256'] == case['sha256']
    if outcome == 'admitted':
        expected = copy.deepcopy(case['expectedReport'])
        expected['archive'] = str(BASE / case['path'])
        expected['limits'] = selected
        assert sha(json.dumps(expected, sort_keys=True, separators=(',', ':')).encode()) == row['actualReportSha256']
    else:
        assert row['actualReportSha256'] is None
assert observed == expected_keys
assert len(set(re.findall(r'test payload_context_acceptance::(\w+) \.\.\. ', log))) == 13

print(json.dumps(dict(reviewedHead=HEAD, reviewedTree=TREE, parent=PARENT,
    exactOnlyWorkflowArgumentChange=True, changedPaths=15, unchangedProductionFiles=97,
    unchangedOtherAcceptanceFiles=236, immutableCopiedPrecodeFilesVerified=4,
    losslessRetainedFailureAndProbeRecords=record_count, retainedIndicesSha256=indices,
    actualProbeSourceBase=PARENT, actualProbeWorkflowSha256=sha(workflow),
    actualProbePassed=13, actualProbeFiltered=354, actualContextRecords=82,
    completeAdmittedReportHashesVerified=41, resourceLimitRows=41,
    parserSelectedInputHashesVerified=len(receipt['sourceAndInputSha256']),
    actualUnitSha256=unit_hash, actualUnitHeaderFromCargo=True,
    cargoLogRecordsCompilationBeforeByteIdenticalUnit=True,
    probeLogSha256=sha(log_raw), parserReceiptSha256=sha(receipt_raw),
    allFreshRecordsIntact=True, originalCorruptLogUnmodified=True,
    decision='Bounded local CI scheduling/capture correction accepted',
    freshFull367ResultClaimed=False, remoteAccepted=False, mergeAccepted=False,
    executionsRebound=False, reviewerMutatedRepository=False, reviewerUsedCargo=False,
    reviewerExecutedTarget=False,
    pending=['New exact-head full remote native CI and uploaded context/public records', 'Five exact-head wheel builds and ten installed-wheel validations', 'Four official Blender/platform lanes']), indent=2))
