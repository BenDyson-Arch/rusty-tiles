import pathlib, hashlib, json, re

base = pathlib.Path(__file__).parent
head = '4dc8f0c04dd5a98420768d05c6787f3baa49bb75'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
receipts = []
wheels = {}
for folder in sorted((base / 'artifacts').iterdir()):
    receipt = json.loads((folder / 'receipt.json').read_text())
    assert receipt['head'] == head
    assert receipt['artifactMetadata']['workflow_run']['head_sha'] == head
    assert receipt['publisherDigestMatchesArchive'] is True
    assert receipt['publisherDigest'] == 'sha256:' + sha(folder / 'artifact.zip')
    assert receipt['archiveSha256'] == sha(folder / 'artifact.zip')
    for member in receipt['members']:
        file = folder / 'files' / member['path']
        assert file.stat().st_size == member['bytes'] and sha(file) == member['sha256']
    receipts.append({'path': str(folder / 'receipt.json'), 'sha256': sha(folder / 'receipt.json'),
                     'name': receipt['name'], 'artifactId': receipt['id'], 'run': receipt['run']})
    if receipt['name'].startswith('wheel-'):
        files = list((folder / 'files').glob('*.whl'))
        assert len(files) == 1 and receipt['run'] == 38050915448
        wheels[receipt['name'][6:]] = {'path': str(files[0]), 'sha256': sha(files[0]),
                                    'artifactId': receipt['id']}
assert len(receipts) == 15 and len(wheels) == 5
installed = []
blender = []
platform_map = {'linux-x64': 'x86_64-unknown-linux-gnu', 'macos-arm64': 'aarch64-apple-darwin',
                'macos-x64': 'x86_64-apple-darwin', 'windows-x64': 'x86_64-pc-windows-msvc'}
for folder in sorted((base / 'artifacts').iterdir()):
    name = json.loads((folder / 'receipt.json').read_text())['name']
    if name.startswith('evidence-wheel-'):
        platform = name[len('evidence-wheel-'):]
        for version in ('3.10', '3.14'):
            p = folder / 'files' / ('python-' + version + '.json')
            d = json.loads(p.read_text())
            assert d['python'].startswith(version + '.')
            assert d['wheel_sha256'] == wheels[platform]['sha256']
            assert d['tests_run'] == 44 and d['ok'] is True and d['empty_path'] is True
            assert d['package_version'] == '0.4.0'
            assert all(d[k] == 0 for k in ('failures', 'errors', 'skipped'))
            installed.append({'platform': platform, 'python': version, 'receipt': str(p),
                              'receiptSha256': sha(p), 'wheelSha256': d['wheel_sha256']})
    elif name.startswith('evidence-official-blender-'):
        platform = name[len('evidence-official-blender-'):]
        p = folder / 'files' / 'blender-acceptance.json'
        distp = folder / 'files' / 'blender-distribution.json'
        d, dist = json.loads(p.read_text()), json.loads(distp.read_text())
        assert d['blender_distribution'] == dist
        assert d['wheel_sha256'] == wheels[platform_map[platform]]['sha256']
        assert d['tests_run'] == 44 and d['ok'] is True and d['empty_path'] is True
        assert all(d[k] == 0 for k in ('failures', 'errors', 'skipped'))
        assert d['package_version'] == '0.4.0' and d['blender_version'] == [4, 5, 14]
        assert dist['distribution'] == 'official-blender.org' and dist['distribution_platform'] == platform
        assert dist['version'] == '4.5.14'
        assert dist['archive_url'].startswith('https://download.blender.org/release/Blender4.5/blender-4.5.14-')
        assert dist['checksum_url'] == 'https://download.blender.org/release/Blender4.5/blender-4.5.14.sha256'
        assert re.fullmatch('[0-9a-f]{64}', dist['archive_sha256'])
        assert re.fullmatch('[0-9a-f]{64}', dist['executable_sha256'])
        blender.append({'platform': platform, 'acceptanceReceipt': str(p), 'acceptanceSha256': sha(p),
                        'distributionReceipt': str(distp), 'distributionSha256': sha(distp),
                        'wheelSha256': d['wheel_sha256']})
assert len(installed) == 10 and len(blender) == 4
out = {'head': head, 'artifactReceipts': receipts, 'wheels': wheels,
       'installedReceipts': installed, 'officialBlenderReceipts': blender,
       'scope': 'Downloaded artifact and wheel bytes rehashed locally; job-produced installed and official Blender receipts verified. Official Blender archive/executable and test binaries are job-computed pins, not downloaded binaries rehashed here.'}
dest = base / 'platform-verification.json'
assert not dest.exists()
dest.write_text(json.dumps(out, indent=2) + '\n')
print('PASS 15 artifact archives, 5 actual wheel hashes, 10 installed receipts, 4 official Blender receipt pairs')
print('receipt', sha(dest))
