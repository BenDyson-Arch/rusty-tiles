"""Inspect actual uploaded C1 records, outer publisher digest and exact source."""
import base64
import copy
import hashlib
import importlib.util
import io
import json
import pathlib
import re
import subprocess
import tarfile
import zipfile

REPO = pathlib.Path('/tmp/rusty-tiles-c1-payload-foundation')
EXTERNAL = pathlib.Path('/tmp/rusty-tiles-payload-final-evidence/remote-4dc8f0c')
ARTIFACT = EXTERNAL / 'artifacts/11669407866-c1-validation-evidence'
FILES = ARTIFACT / 'files'
HEAD = '4dc8f0c04dd5a98420768d05c6787f3baa49bb75'
TREE = '57095507d251e4f2fcb826cee367fa72bd306158'
PREVIEW = '2a13c3268233d20218e867a4436d3e6b84770c7b'
RUN = 38050915453
BASE = REPO / 'bench/architecture_audit/c1_payload_integrity/production_controls'
PIN = json.loads((EXTERNAL / 'correction-source-pin.json').read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


assert git('rev-parse', HEAD + '^{tree}').decode().strip() == TREE
assert git('rev-parse', PREVIEW + '^{tree}').decode().strip() == TREE
assert HEAD in git('show', '-s', '--format=%P', PREVIEW).decode().split()
for group in ['production_sha256', 'acceptance_inputs_sha256']:
    for path, digest in PIN[group].items():
        assert sha(git('show', HEAD + ':' + path)) == sha((REPO / path).read_bytes()) == digest
receipt = read_json(ARTIFACT / 'receipt.json')
archive_raw = (ARTIFACT / 'artifact.zip').read_bytes()
assert receipt['run'] == RUN and receipt['head'] == HEAD and receipt['id'] == 11669407866
assert receipt['archiveSha256'] == sha(archive_raw) and receipt['archiveBytes'] == len(archive_raw) == 148706
metadata = receipt['artifactMetadata']
assert metadata['workflow_run']['id'] == RUN and metadata['workflow_run']['head_sha'] == HEAD
assert metadata['id'] == receipt['id'] and metadata['name'] == receipt['name'] == 'c1-validation-evidence'
assert metadata['size_in_bytes'] == len(archive_raw)
assert metadata['digest'] == receipt['publisherDigest'] == 'sha256:' + sha(archive_raw)
with zipfile.ZipFile(io.BytesIO(archive_raw)) as archive:
    assert archive.testzip() is None
    supplied = {member.filename: archive.read(member.filename) for member in archive.infolist() if not member.is_dir()}
assert len(supplied) == len(receipt['members']) == 8
assert supplied.keys() == {row['path'] for row in receipt['members']}
for row in receipt['members']:
    raw = supplied[row['path']]
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
    assert raw == (FILES / row['path']).read_bytes()

context = read_json(FILES / 'c1-payload-contexts.json')
log = (FILES / 'c1-library.log').read_text()
assert context['sourceCommit'] == PREVIEW and context['sourceTree'] == TREE
assert context['logSha256'] == sha(supplied['c1-library.log'])
assert context['runnerSha256'] == sha((REPO / 'tests/payload_context_receipt.py').read_bytes())
for path, digest in context['sourceAndInputSha256'].items():
    assert sha((REPO / path).read_bytes()) == digest
assert len(context['sourceAndInputSha256']) == 327
assert re.search(r'Running unittests src/lib.rs \(target/debug/deps/rusty_tiles-a3b18c039bb13d7b\)', log)
assert re.search(r'^test result: ok\. 367 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', log, re.M)
for test in ['runtime::tests::concurrent_create_new_publishers_install_exactly_one_candidate', 'runtime::directory::tests::separate_process_commits_during_absence_and_failed_restore_preserves_it', 'runtime::directory::tests::separate_process_may_replace_an_already_committed_output']:
    assert 'test ' + test + ' ... ' in log
decoder = json.JSONDecoder()
rows = [decoder.raw_decode(line[line.index('{"actualReportSha256"'):])[0] for line in log.splitlines() if '{"actualReportSha256"' in line]
assert len(rows) == context['passes'] == 82 and rows == context['executions']
case_root = BASE / 'context_controls/2026-10-10'
cases = {case['name']: case for case in read_json(case_root / 'fixtures/manifest.json')['cases']}
baseline = dict(jsonBytes=65536, jsonDepth=32, memberBytes=262144, archiveStoredBytes=1048576, archiveEntries=256, accessorElements=4096, documentDecodedBytes=262144, hierarchyVisits=128, hierarchyDepth=32, references=1024, totalPayloadElements=16, totalBytesRead=4194304, sourceArchiveBytes=1048576, centralDirectoryBytes=65536, documentItems=8192)
expected_keys = {(case['name'], fact, outcome) for case in cases.values() for fact in (['bytes', 'depth', 'nodes'] if case['target'] else ['totalPayloadElements']) for outcome in ['admitted', 'resource_limit']}
observed = set()
remote_root = '/home/runner/work/rusty-tiles/rusty-tiles/'
for row in rows:
    name, fact, outcome = row['independentContextControl'], row['fact'], row['outcome']
    key = name, fact, outcome
    assert key not in observed
    observed.add(key)
    case = cases[name]
    exact = case['metrics'][name][fact] if case['target'] else case['aggregateEquality']
    selected = baseline.copy()
    selected[dict(bytes='jsonBytes', depth='jsonDepth', nodes='documentItems').get(fact, fact)] = exact - (outcome == 'resource_limit')
    assert row['selectedLimits'] == selected and row['readOnly'] is True and row['archiveSha256'] == case['sha256']
    if outcome == 'admitted':
        expected = copy.deepcopy(case['expectedReport'])
        expected['archive'] = remote_root + str(case_root.relative_to(REPO)) + '/' + case['path']
        expected['limits'] = selected
        assert sha(json.dumps(expected, sort_keys=True, separators=(',', ':')).encode()) == row['actualReportSha256']
    else:
        assert row['actualReportSha256'] is None
assert expected_keys == observed
assert len(set(re.findall(r'^test payload_context_acceptance::(\w+) \.\.\. ', log, re.M))) == 13
assert len(set(re.findall(r'^test payload_stride_acceptance::(\w+) \.\.\. ', log, re.M))) == 2

public = read_json(FILES / 'c1-payload-integrity.json')
assert public['runnerExitCode'] == 0 and 'runnerFailure' not in public
assert public['runnerSha256'] == sha((REPO / 'tests/payload_integrity_oracle.py').read_bytes())
assert public['adjudicationSha256'] == sha((BASE / 'polygon_correction/2026-10-10/adjudication.md').read_bytes())
binary_hashes = set()
report_count = 0
stream_count = 0
for label, filename, count in [('corrected205', 'corrected-205-fixtures.tar.gz', 205), ('polygon5', 'polygon-sensitive-5-fixtures.tar.gz', 5)]:
    phase = public['phases'][label]
    bundle_path = BASE / 'polygon_correction/2026-10-10' / filename
    with tarfile.open(bundle_path) as archive:
        bundle = {member.name: archive.extractfile(member).read() for member in archive.getmembers() if member.isfile()}
    manifest = json.loads(bundle['manifest.json'])
    assert phase['manifestSha256'] == sha(bundle['manifest.json'])
    assert phase['passes'] == phase['expectedCaseCount'] == count and phase['failures'] == 0
    assert phase['sourceAndBinaryUnchanged'] and phase['fixturesUnchanged']
    assert phase['sourcePin']['source_commit'] == PREVIEW and phase['sourcePin']['source_tree'] == TREE
    assert phase['sourcePin']['production_sha256'] == PIN['production_sha256']
    assert phase['sourcePin']['runner_sha256'] == public['runnerSha256']
    assert phase['sourcePin']['fixture_bundle_sha256'] == sha(bundle_path.read_bytes())
    assert phase['driverSha256'] == manifest['driverSha256'] == sha((BASE / 'driver.py').read_bytes())
    for path, digest in phase['sourceSnapshot'].items():
        assert sha((REPO / path).read_bytes()) == digest
    assert phase['fixturesBefore'] == {name: sha(raw) for name, raw in bundle.items()}
    declared = {case['name']: case for case in manifest['cases']}
    assert len(phase['cases']) == count and {case['name'] for case in phase['cases']} == declared.keys()
    binary_hashes.add(phase['binarySha256'])
    for row in phase['cases']:
        case = declared[row['name']]
        assert row['passed'] is True and row['observedCategory'] == row['expectedCategory'] == case['expectedCategory']
        assert row['exitCode'] == case['expectedExitCode']
        assert row['archiveSha256'] == case['sha256'] == sha(bundle[case['path']])
        stdout = base64.b64decode(row['stdoutBase64'], validate=True)
        stderr = base64.b64decode(row['stderrBase64'], validate=True)
        assert sha(stdout) == row['stdoutSha256'] and sha(stderr) == row['stderrSha256']
        response = json.loads(stdout)
        assert response == row['response']
        stream_count += 2
        expected = copy.deepcopy(case['expectedReport'])
        if expected is not None:
            expected['archive'] = row['command'][-1]
            assert response == expected == row['expectedReport']
            report_count += 1
        else:
            assert response['error']['code'] == case['expectedCategory'] and response['exitCode'] == case['expectedExitCode']

stride = read_json(FILES / 'c1-payload-stride.json')
assert stride['coordinatorRunnerSha256'] == sha((REPO / 'tests/payload_meshopt_stride_oracle.py').read_bytes())
for dirname, label, count in [('stride_controls', 'stride6', 6), ('stride_parent_control', 'parent1', 1)]:
    root = BASE / dirname / '2026-10-10'
    manifest = read_json(root / 'fixtures/manifest.json')
    phase = stride['phases'][label]
    assert phase['runnerExitCode'] == 0 and phase['passes'] == count and phase['failures'] == 0
    assert phase['artifactIdentitiesUnchanged'] and phase['fixturesAndReferencesUnchanged']
    assert phase['sourcePin']['source_commit'] == PREVIEW and phase['sourcePin']['source_tree'] == TREE
    assert phase['sourcePin']['production_sha256'] == PIN['production_sha256']
    assert phase['manifestSha256'] == sha((root / 'fixtures/manifest.json').read_bytes())
    assert phase['runnerSha256'] == manifest['runnerSha256'] == sha((root / 'runner.py').read_bytes())
    for path, digest in phase['fixturesBefore'].items():
        assert sha((root / 'fixtures' / path).read_bytes()) == digest
    declared = {case['name']: case for case in manifest['cases']}
    assert len(phase['cases']) == count and {case['name'] for case in phase['cases']} == declared.keys()
    binary_hashes.add(phase['binarySha256'])
    for row in phase['cases']:
        case = declared[row['name']]
        assert row['passed'] is True and row['observedCategory'] == row['expectedCategory'] == case['expectedCategory']
        assert row['exitCode'] == case['expectedExitCode']
        assert row['archiveSha256'] == case['sha256'] == sha((root / 'fixtures' / case['path']).read_bytes())
        stdout = base64.b64decode(row['stdoutBase64'], validate=True)
        stderr = base64.b64decode(row['stderrBase64'], validate=True)
        assert sha(stdout) == row['stdoutSha256'] and sha(stderr) == row['stderrSha256']
        response = json.loads(stdout)
        assert response == row['response']
        stream_count += 2
        expected = copy.deepcopy(case['expectedReport'])
        if expected is not None:
            expected['archive'] = row['command'][-1]
            assert response == expected == row['expectedReport']
            report_count += 1
        elif 'expectedErrorReport' in case:
            assert response == case['expectedErrorReport'] and stderr == b''
        else:
            assert response['error']['code'] == case['expectedCategory'] and response['exitCode'] == case['expectedExitCode']
assert len(binary_hashes) == 1 and report_count == 82 and stream_count == 434

archives = read_json(FILES / 'c1-archive-read.json')
driver = REPO / 'bench/architecture_audit/implicit_rewrite/archive_read_acceptance/probe.py'
spec = importlib.util.spec_from_file_location('independent_archive_truth', driver)
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
truth = {row['label']: row for row in oracle.fixtures()}
assert len(archives['records']) == len(truth) == 45
assert archives['fixture_driver_sha256'] == sha(driver.read_bytes())
assert archives['runner_sha256'] == sha((REPO / 'tests/archive_read_oracle.py').read_bytes())
assert archives['source_commit'] == PREVIEW and archives['read_only'] is True
for row in archives['records']:
    known = truth[row['label']]
    assert row['archive_sha256'] == sha(known['raw'])
    assert row['actual'] == row['expected'] == known['expected'] == oracle.classify(known['raw'])['kind']
    response = json.loads(row['stdout'])
    assert row['exit_code'] == {'admitted': 0, 'unsupported': 2, 'invalid_input': 3}[row['actual']]
    assert response['ok'] is True if row['actual'] == 'admitted' else response['error']['code'] == row['actual']
corpus = read_json(FILES / 'c1-validation.json')
assert corpus['readOnly'] is True and len(corpus['cases']) == 135
assert len({case['name'] for case in corpus['cases']}) == 135
for case in corpus['cases']:
    response = case['report']
    assert case['exitCode'] == (0 if response.get('ok') is True else response['exitCode'])
    if response.get('ok') is True:
        assert len(response['checks']) == 13 and len(response['limits']) == 15
resources = read_json(FILES / 'c1-resources.json')
runs = resources['runs']
assert resources['readOnly'] is True and len(runs) == 20
assert len({(row['name'], row['repetition']) for row in runs}) == 20
for row in runs:
    assert row['maximumRssKiB'] > 0 and row['wallSeconds'] < 30 and row['descriptorSamples'] > 0
    if row['name'] in ['triangle', 'legal_shared_indices']:
        assert row['exitCode'] == 0 and row['report']['ok'] is True
    else:
        assert row['exitCode'] == 3 and row['report']['error']['code'] == 'resource_limit'
producer = read_json(FILES / 'c1-producer.json')
assert producer['sourceReadOnly'] is True
assert producer['sourceSha256'] == sha((REPO / 'tests/fixtures/c1-framing-staircase.geojson').read_bytes())
assert producer['counts']['features'] == producer['counts']['fragmentedPolygons'] == 1 and producer['counts']['skippedFeatures'] == 0
assert len(producer['controls']) == 8
for row in producer['controls']:
    assert row['b3dmBytes'] % 8 == 0 and row['glbBytes'] % 4 == 0
    assert 0 <= row['binBytes'] - row['declaredBufferBytes'] <= 3
for digest in [archives['binary_sha256'], corpus['binarySha256'], resources['binarySha256'], producer['binarySha256']]:
    assert digest in binary_hashes

print(json.dumps(dict(head=HEAD, tree=TREE, actualExecutionCommit=PREVIEW, executionTreeEqualsHeadTree=True,
    run=RUN, artifact=11669407866, publisherDigestVerified=True, archiveSha256=sha(archive_raw),
    allEightUploadedMembersHashChecked=True, actualLibraryPassed=367, failed=0, ignored=0, filtered=0,
    ownedConcurrencyTestsPresent=True, actualContextCalls=82, admittedReportHashesVerified=41,
    resourceLimitRows=41, contextInputHashesVerified=327, publicCases=217,
    completePublicPositiveReports=report_count, originalPublicStreamsVerified=stream_count,
    unitHashReportedByPinnedJobParser=context['unitSha256'], cliHashReportedByPinnedJobHarnesses=next(iter(binary_hashes)),
    cliFeatures='native-jpeg, default features empty, debug profile',
    binariesIncludedInC1Upload=False, reviewerIndependentlyRehashedRemoteBinaries=False,
    originalC1ReportShapes=135, independentlyReclassifiedArchiveCases=45, resourceRuns=20,
    rssKiBRange=[min(row['maximumRssKiB'] for row in runs), max(row['maximumRssKiB'] for row in runs)],
    descriptorSamples=sum(row['descriptorSamples'] for row in runs), sampledPeakDescriptors=max(row['peakDescriptors'] for row in runs),
    descriptorPermissionDenials=sum(row['descriptorPermissionDenials'] for row in runs),
    maximumWallSeconds=max(row['wallSeconds'] for row in runs), producerReportedFramingMembers=8,
    producerArchiveIncludedInUpload=False, reviewerDecodedRemoteProducerArchive=False,
    boundedRemoteC1CheckpointVerified=True, entireCiAccepted=False, wheelsAndBlenderAccepted=False, mergeAccepted=False,
    reviewerUsedCargo=False, reviewerExecutedTarget=False, reviewerMutatedRepository=False,
    limits=['Unit/CLI hashes were computed by pinned actual job harnesses; those binary bytes are not in this upload', 'Remote descriptor observations include19 permission-denial events; sampled peak is partial, no universal ceiling', 'Producer raw output archive is not in this upload; framing assertions belong to the pinned job runner', 'Whole-run/job completion and all wheel/Blender gates remain separate']), indent=2))
