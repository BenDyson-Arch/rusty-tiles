# Separate uploaded C1 checkpoint review, 2026-10-10

**The bounded remote C1 checkpoint verifies successfully** for PR153 head
`4dc8f0c04dd5a98420768d05c6787f3baa49bb75`, tree
`57095507d251e4f2fcb826cee367fa72bd306158`, CI run38050915453. This is not
whole-CI, wheel/Blender or merge acceptance. Separate reviewer
`/root/payload_final_source_review` inspected actual uploaded bytes and source
identities with no Cargo, target execution or repository mutation.

Artifact11669407866, c1-validation-evidence, is148706 bytes. Its actual ZIP SHA256
`d1486068b93ce56146473507f92fc335a068ae918b52a42beca37338e2d0d6c9`
matches the publisher digest and captured metadata names the exact current run
and head. All eight ZIP members pass CRC, member lengths/hashes and extracted
byte comparison. The actual execution names pull merge preview
`2a13c3268233d20218e867a4436d3e6b84770c7b`; its actual Git tree equals the
final head tree and4dc is a parent. That preview remains a distinct execution
identity. All97 production/237 selected inputs match the reviewed correction
pin; all327 actual context source/control hashes match the exact tree.

The uploaded native-JPEG/debug Cargo log records the authentic library unit and
full367 passed, zero failed/ignored/filtered. The owned scoped-thread and joined
subprocess concurrency tests are present in that successful full run; this is
not the earlier13-test targeted local probe. Both stride tests and all13 context
tests execute. All82 JSON records parse intact and exactly match the unchanged
parser's receipt. Every planned equality/one-less tuple and fifteen-field limit
mapping matches the independent17-case manifest. The reviewer recomputes all41
complete admitted report hashes using the actual runner checkout path; the other
41 records have typed ResourceLimit outcomes and no admitted report hash. The
original failed5fdf capture remains untouched and is not used to repair this
new successful receipt.

Uploaded log SHA256 is
`d0ca13d85cc0e5f34b8e3f1a4770de960fee9b746cc92a50330fb568e63beed2`;
the context receipt member SHA256 is
`6643421c2dde933ddd1cea05e454b5da53a48db3179ad80ae033c16083b7d9c2`.
The actual pinned job parser reports unit SHA256
`0b988e0e96bb4bc1267497ad448a8b492bb2bc3e034a272e5bd827b26c424000`.
All actual CLI harnesses report the same debug CLI SHA256
`151169080bcafdc05cfecef4a0cea5cc57d9752a0033de9b0b6c2afe6943c12d`.
The C1 upload contains these in-job bindings, not the executable bytes, so the
reviewer does not claim an independent off-job rehash of either binary. The
actual CI command enables native-jpeg; Cargo default features are empty. This
artifact is not the local release native-geospatial/native-jpeg binary and its
identity is not rebound to either local artifact.

The unchanged independent public drivers verify205 corrected plus polygon5,
and two separate immutable stride lanes verify six plus one. All217 cases pass,
with82 complete positive reports and434 original stdout/stderr streams strictly
base64-decoded and hash-checked. Categories/exits, literal manifests, bundle/
archive hashes, source snapshots, driver/runner hashes, read-only flags and
actual parsed responses all match. The unmasked parent control asserts the
complete typed error and empty stderr. The original204/1 polygon history and
old2eb false-Invalid stride history remain separate.

The upload also retains135 original C1 parsed reports and their successful/error
shape,45 archive records independently reclassified from the selected independent
raw truth fixtures,20 resource observations and the producer runner's eight
framing records. The older C1 runner supplies its own expectations/assertions;
these135 uploaded parsed reports are not independent full positive-report
oracles. The context and public lanes supply the full independent reports.
Archive driver/runner hashes and every expected/observed category and exit match.
The resource cases give four legal admissions and sixteen ResourceLimit results.

Remote RSS observations are78248–86324KiB and maximum wall time .585083 seconds.
There are2675 descriptor samples, observed peak6, and **19 permission-denial
events**. This differs from the local zero-denial observations. The observed
remote descriptor peak is partial; no complete fd ceiling, no-denial coverage
or universal process-memory/CPU promise is made. These results do not invent
another production limit or weaken a category assertion.

The actual producer script's unchanged-source hash, feature/count assertions and
eight reported modern b3dm/GLB/BIN framing records match the job's CLI identity.
Its raw produced archive is not in this eight-member upload; the reviewer checks
reported framing arithmetic and pinned runner assertions, and does not claim
independent decoding of unavailable remote producer bytes. Local independent
producer archive decoding remains bound to the original e4ec executions.

This verifies that the corrected scheduling capture executes the full native
library and preserves all82 actual context records, plus the217 independent
public controls, on the exact reviewed tree. Completion of the entire Rust job,
all applicable21 checks, five actual wheel artifacts, ten installed-wheel lanes
and four official Blender/platform lanes remains required. Old5fdf or local
e4ec/targeted-probe results retain their own identities. No merge, A2, wider
semantics/issue closure, main/tag/publication or release acceptance is granted.
