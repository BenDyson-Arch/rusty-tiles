import subprocess,pathlib,json,datetime,hashlib,zipfile
repo='BenDyson-Arch/rusty-tiles';base=pathlib.Path(__file__).parent;head='4dc8f0c04dd5a98420768d05c6787f3baa49bb75';stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');records=[]
for label,run in [('main',38050915453),('wheel',38050915448)]:
 raw=subprocess.check_output(['gh','api',f'repos/{repo}/actions/runs/{run}/artifacts']);(base/(label+'-artifacts-'+stamp+'.json')).write_bytes(raw);items=json.loads(raw)['artifacts']
 for item in items:
  name=item['name']
  if label=='main' and name!='c1-validation-evidence':continue
  if label=='wheel' and not name.startswith(('wheel-','evidence-wheel-','evidence-official-blender-')):continue
  assert not item['expired'] and item['workflow_run']['head_sha']==head
  folder=base/'artifacts'/(str(item['id'])+'-'+name)
  if folder.exists():continue
  folder.mkdir(parents=True);archive=folder/'artifact.zip'
  with archive.open('wb') as stream:subprocess.run(['gh','api',f"repos/{repo}/actions/artifacts/{item['id']}/zip",'--allow-escape-sequences'],stdout=stream,check=True)
  sha=hashlib.sha256(archive.read_bytes()).hexdigest();publisher=item.get('digest');row={'run':run,'head':head,'name':name,'id':item['id'],'archiveBytes':archive.stat().st_size,'archiveSha256':sha,'publisherDigest':publisher,'publisherDigestMatchesArchive':publisher=='sha256:'+sha,'artifactMetadata':item,'members':[]}
  with zipfile.ZipFile(archive) as z:
   for info in z.infolist():
    if info.is_dir():continue
    path=pathlib.PurePosixPath(info.filename);assert not path.is_absolute() and '..' not in path.parts
    data=z.read(info);dest=folder/'files'/info.filename;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);row['members'].append({'path':info.filename,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
  (folder/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');records.append(row);print(json.dumps({k:row[k] for k in ['name','id','archiveBytes','publisherDigestMatchesArchive']}),flush=True)
(base/('artifact-collection-'+stamp+'.json')).write_text(json.dumps(records,indent=2)+'\n');print('collected',len(records),flush=True)
