import subprocess,pathlib,json,datetime,collections
repo='BenDyson-Arch/rusty-tiles';base=pathlib.Path(__file__).parent;stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');out=base/('snapshot-'+stamp);out.mkdir()
queries={'pr.json':['gh','pr','view','153','--repo',repo,'--json','number,url,headRefOid,baseRefName,state,mergeable,statusCheckRollup'],'main-run.json':['gh','api','repos/'+repo+'/actions/runs/38050915453'],'wheel-run.json':['gh','api','repos/'+repo+'/actions/runs/38050915448']}
for name,argv in queries.items():
 raw=subprocess.check_output(argv);(out/name).write_bytes(raw);d=json.loads(raw)
 if name=='pr.json':
  assert d['headRefOid']=='4dc8f0c04dd5a98420768d05c6787f3baa49bb75';print('PR153',d['state'],d['mergeable'],dict(collections.Counter(x['conclusion'] or x['status'] for x in d['statusCheckRollup'])))
  for x in d['statusCheckRollup']:
   if x['conclusion'] not in ('SUCCESS','SKIPPED',''):print(x['name'],x['conclusion'],x['detailsUrl'])
 else:assert d['head_sha']=='4dc8f0c04dd5a98420768d05c6787f3baa49bb75';print(name,d['status'],d['conclusion'])
print('snapshot',str(out))
