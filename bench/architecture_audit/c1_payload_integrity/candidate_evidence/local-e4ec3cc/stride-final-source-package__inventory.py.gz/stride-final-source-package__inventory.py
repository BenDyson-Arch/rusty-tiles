import pathlib,json,hashlib,tarfile,subprocess,tomllib
out=pathlib.Path(__file__).parent;base=out.parent;root=pathlib.Path('/tmp/rusty-tiles-c1-payload-foundation');receipt=json.loads((out/'receipt.json').read_text());assert receipt['exit_code']==0
archive=next(out.glob('*.crate'));sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(archive.read_bytes())==receipt['archive_sha256'];rows=[];special={}
with tarfile.open(archive) as tf:
 for m in tf.getmembers():
  if not m.isfile():continue
  data=tf.extractfile(m).read();rel=m.name.split('/',1)[1];row={'path':rel,'bytes':len(data),'sha256':sha(data)}
  if rel in ('Cargo.toml','Cargo.lock','.cargo_vcs_info.json','Cargo.toml.orig'):special[rel]=data
  else:
   tracked=subprocess.check_output(['git','show','e4ec3cc:'+rel],cwd=root,stderr=subprocess.DEVNULL);assert tracked==data,rel;row['trackedSource']='byte-identical e4ec3cc'
  rows.append(row)
assert special['Cargo.toml.orig']==(root/'Cargo.toml').read_bytes()
vcs=json.loads(special['.cargo_vcs_info.json']);assert vcs['git']['sha1']==receipt['source_commit'] and not vcs['git'].get('dirty',False)
orig=tomllib.loads((root/'Cargo.lock').read_text());pack=tomllib.loads(special['Cargo.lock'].decode());key=lambda x:(x['name'],x['version']);op={key(x):x for x in orig['package']};pp={key(x):x for x in pack['package']};assert all(op.get(k)==v for k,v in pp.items());removed=[list(k) for k in sorted(op.keys()-pp.keys())];assert len(removed)==8
pin=json.loads((base/'stride-final-build/source-pin.json').read_text());byname={x['path']:x for x in rows};exact=[];excluded=[]
for group in ('production_sha256','acceptance_inputs_sha256'):
 for name,h in pin[group].items():
  if name in ('Cargo.toml','Cargo.lock'):continue
  if name not in byname:excluded.append(name);continue
  assert byname[name]['sha256']==h,name;exact.append(name)
assert all(x.startswith(('.github/','bindings/python/')) for x in excluded),excluded
inventory={'sourceCommit':receipt['source_commit'],'sourceTree':receipt['source_tree'],'archiveSha256':receipt['archive_sha256'],'archiveBytes':receipt['archive_bytes'],'frozenArchive':str(archive),'regularMembers':len(rows),'ordinaryByteIdenticalMembers':len(rows)-4,'exactSelectedPaths':exact,'excludedWorkspaceOrCiPaths':excluded,'normalization':{'originalManifestByteIdentical':True,'originalLockPackages':len(op),'packagedLockPackages':len(pp),'everyRetainedPackageTableIdentical':True,'pythonOnlyPrunedPackages':removed,'note':'First inventory assertion expected raw Cargo.lock equality; packaged root normalization prunes eight Python-only package tables. No package command or archive rerun; original build receipt unchanged.'},'records':rows};(out/'archive-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n');print(json.dumps({k:v for k,v in inventory.items() if k not in ('records','exactSelectedPaths')}));print('exact selected',len(exact))
