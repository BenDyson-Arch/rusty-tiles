import subprocess,json,pathlib,hashlib,os,time
root=pathlib.Path('/tmp/rusty-tiles-c1-payload-foundation')
out=pathlib.Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=json.loads(pathlib.Path('/tmp/rusty-tiles-payload-final-evidence/stride-final-build/source-pin.json').read_text())
for group in ('production_sha256','acceptance_inputs_sha256'):
 for name,h in pin[group].items():assert sha(root/name)==h,name
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
argv=['nice','-n','10','python3','/tmp/rusty-tiles-archive-read-final-evidence/run-controlled.py','cargo','package','--locked','-p','rusty-tiles']
t=time.time()
with (out/'package-verify.log').open('wb') as log:
 r=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
for group in ('production_sha256','acceptance_inputs_sha256'):
 for name,h in pin[group].items():assert sha(root/name)==h,name
archive=pathlib.Path('/tmp/rusty-tiles-f1d2-final-target/package/rusty-tiles-0.4.0.crate')
d={'source_commit':commit,'source_tree':tree,'unchanged_local_execution_source':pin['source_commit'],'source_pin_sha256':sha(pathlib.Path('/tmp/rusty-tiles-payload-final-evidence/stride-final-build/source-pin.json')),'argv':argv,'exit_code':r.returncode,'elapsed_seconds':time.time()-t,'log_sha256':sha(out/'package-verify.log'),'archive_sha256':sha(archive) if archive.exists() else None,'archive_bytes':archive.stat().st_size if archive.exists() else None,'scope':'Actual cargo package with default verification, compiling extracted root crate; no publication or installed artifact claim'}
(out/'receipt.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d),flush=True)
raise SystemExit(r.returncode)
