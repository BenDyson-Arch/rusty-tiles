import subprocess,json,pathlib,hashlib,shutil,os,re,time,sys
root=pathlib.Path('/tmp/rusty-tiles-c1-payload-foundation')
base=pathlib.Path('/tmp/rusty-tiles-payload-final-evidence/stride-corrected-build');base.mkdir(exist_ok=True)
pinpath=base/'source-pin.json';pin=json.loads(pinpath.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cap=['nice','-n','10','python3','/tmp/rusty-tiles-archive-read-final-evidence/run-controlled.py']
def verify():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==pin['source_commit']
 for group in ('production_sha256','acceptance_inputs_sha256'):
  for name,h in pin[group].items():assert sha(root/name)==h,name
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
def run(name,args,freeze=None):
 verify();started=time.monotonic();log=base/(name+'.log')
 with log.open('wb') as f:r=subprocess.run(cap+args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 verify();d={'source_commit':pin['source_commit'],'source_tree':pin['source_tree'],'source_pin_sha256':sha(pinpath),'argv':cap+args,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-started,'log_sha256':sha(log),'all_inputs_unchanged':True}
 if r.returncode==0 and freeze:
  source=freeze(log);h=sha(source);dest=base/(name+'-'+pin['source_commit'][:7]+'-'+h);shutil.copyfile(source,dest);assert sha(dest)==h;d.update(frozen_artifact=str(dest),artifact_sha256=h,artifact_bytes=dest.stat().st_size)
 (base/(name+'-receipt.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True)
 assert r.returncode==0,log
 return d
unit=run('library',['cargo','test','--locked','--release','--no-default-features','--lib','--','--nocapture'],lambda log:pathlib.Path(re.search(r'Running unittests src/lib.rs \(([^)]+)\)',log.read_text())[1]))
text=(base/'library.log').read_text();m=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text);assert m
unit['library_result']=dict(zip(['passed','failed','ignored','measured','filtered_out'],map(int,m.groups())))
assert unit['library_result']['passed']>=365 and not any(unit['library_result'][k] for k in ['failed','ignored','filtered_out'])
(base/'library-receipt.json').write_text(json.dumps(unit,indent=2)+'\n')
run('context-parser',['python3','-B','tests/payload_context_receipt.py','--log',str(base/'library.log'),'--output',str(base/'context-harness-receipt.json')])
run('native-clippy',['env','LIBSQLITE3_SYS_USE_PKG_CONFIG=1','cargo','clippy','--locked','--release','--all-targets','--features','native-geospatial,native-jpeg','--','-D','warnings'])
run('bindings-clippy',['env','LIBSQLITE3_SYS_USE_PKG_CONFIG=1','cargo','clippy','--locked','--release','-p','rusty-tiles-python','--','-D','warnings'])
for flavor,args in [('portable',['--no-default-features']),('native',['--features','native-geospatial,native-jpeg'])]:
 d=run(flavor+'-cli',(['env','LIBSQLITE3_SYS_USE_PKG_CONFIG=1'] if flavor=='native' else [])+['cargo','build','--locked','--release','--bin','rusty-tiles']+args,lambda log:pathlib.Path('/tmp/rusty-tiles-f1d2-final-target/release/rusty-tiles'))
 (base/(flavor+'-cli.path')).write_text(d['frozen_artifact'])
