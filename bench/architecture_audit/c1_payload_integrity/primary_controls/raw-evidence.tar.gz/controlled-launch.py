import json, os, sys
os.setpriority(os.PRIO_PROCESS, 0, 10)
available = sorted(os.sched_getaffinity(0))
os.sched_setaffinity(0, set(available[:2]))
os.environ.update(RAYON_NUM_THREADS="2", RUST_TEST_THREADS="2", CARGO_BUILD_JOBS="2")
with open(sys.argv[1], "w") as record:
    json.dump({"nice":os.getpriority(os.PRIO_PROCESS,0), "affinity":sorted(os.sched_getaffinity(0)), "rayon":"2"}, record)
os.execvpe(sys.argv[2], sys.argv[2:], os.environ)
